<?php
namespace OpenCATS\UI;

class CandidateQuickActionMenu extends QuickActionMenu
{
    protected function getMenuType()
    {
        return 'quickAction.CandidateMenu';
    }
}